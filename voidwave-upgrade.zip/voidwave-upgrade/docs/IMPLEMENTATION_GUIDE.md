# VOIDWAVE Smart Menu System - Implementation Guide

**Version:** 1.0
**Target:** Claude Code CLI / Codex
**Project:** VOIDWAVE v10.0.0+

---

## Executive Summary

This guide details upgrading VOIDWAVE's menu system from basic manual-input menus to an intelligent, context-aware system that:

1. **Auto-scans** before attacks requiring targets
2. **Pre-flight checks** validate requirements before execution
3. **Help system** via `?` or `H` option shows detailed descriptions
4. **Smart targeting** - scan results become selectable lists
5. **Auto-fix** attempts to resolve missing requirements

---

## Directory Structure

```
VOIDWAVE/
├── lib/
│   ├── intelligence/           # NEW - Smart automation layer
│   │   ├── help.sh            # Help system with descriptions
│   │   ├── preflight.sh       # Requirement checking
│   │   ├── targeting.sh       # Network scanning & selection
│   │   └── wireless_menu_smart.sh  # Upgraded wireless menu
│   ├── menus/
│   │   ├── wireless_menu.sh   # REPLACE with smart version
│   │   ├── recon_menu.sh      # Upgrade pattern applies here
│   │   ├── scan_menu.sh       # Upgrade pattern applies here
│   │   └── ...
│   └── menu.sh                # Main menu - update to use smart menus
└── ...
```

---

## Implementation Tasks

### Phase 1: Core Intelligence Layer

#### Task 1.1: Install Intelligence Modules

Copy the provided files into `lib/intelligence/`:
- `help.sh` - Help system
- `preflight.sh` - Requirement checking
- `targeting.sh` - Target acquisition
- `wireless_menu_smart.sh` - Reference implementation

#### Task 1.2: Source Intelligence in Loader

Update `lib/wireless_loader.sh`:

```bash
# Add to _wireless_core_modules array:
"intelligence/help.sh"
"intelligence/preflight.sh"
"intelligence/targeting.sh"
```

#### Task 1.3: Update Main Menu

In `lib/menu.sh`, update the wireless menu call:

```bash
# Change from:
4) show_wireless_menu_new || true ;;

# To:
4) show_wireless_menu_smart || true ;;
```

---

### Phase 2: Menu Upgrade Pattern

Every menu follows this pattern:

#### 2.1 Menu Display Structure

```bash
show_XXXX_menu_smart() {
    while true; do
        clear_screen
        _show_banner
        _show_status_bar          # Current state
        _show_XXXX_options        # Menu items
        
        local choice
        choice=$(_prompt_choice MAX_NUM)
        
        # Handle help FIRST
        if handle_help_input "$choice" "MENU_NAME"; then
            continue
        fi
        
        # Then handle choice
        _handle_XXXX_choice "$choice"
        
        [[ "$choice" == "0" ]] && return 0
    done
}
```

#### 2.2 Status Bar Shows Current State

```bash
_show_status_bar() {
    # Show: Root status, Interface, Monitor mode, Current target
    echo -e "    [Root] Interface: wlan0 Monitor: wlan0mon Target: MyNetwork"
}
```

#### 2.3 Options Include Help at Bottom

```bash
_show_XXXX_options() {
    echo "    1) Option One"
    echo "    2) Option Two"
    # ...
    echo ""
    echo "    ────────────────────────────"
    echo "    0) Back                ?) Help & Descriptions"
}
```

#### 2.4 Choice Handler Runs Preflight

```bash
_handle_XXXX_choice() {
    case "$1" in
        1) 
            preflight "attack_type" || return 1
            # Then do the attack
            ;;
    esac
}
```

---

### Phase 3: Help System Integration

#### 3.1 Define Help Content

Each menu needs a `MENUNAME_HELP` associative array in `help.sh`:

```bash
declare -gA RECON_HELP=(
    [1]="NMAP SCAN

    Port scanning with nmap.
    
    OPTIONS:
    • Quick scan (-T4)
    • Full scan (-p-)
    • Service detection (-sV)
    
    REQUIRES: nmap installed"

    [2]="MASSCAN
    
    High-speed port scanner.
    ..."
)
```

#### 3.2 Add Help Handler

In each menu's choice handler:

```bash
# At top of choice handling
if handle_help_input "$choice" "recon"; then
    continue
fi
```

---

### Phase 4: Preflight System

#### 4.1 Define Requirements

In `preflight.sh`, add entries to `ATTACK_REQUIREMENTS`:

```bash
declare -gA ATTACK_REQUIREMENTS=(
    # Format: [attack_name]="req1 req2 req3"
    # Use | for OR: "tool1|tool2"
    
    [nmap_scan]="root nmap"
    [masscan_scan]="root masscan"
    [hydra_attack]="root hydra wordlist"
)
```

#### 4.2 Use Preflight in Attack Functions

```bash
_do_nmap_scan() {
    # Check requirements FIRST
    preflight "nmap_scan" || return 1
    
    # Then proceed with attack
    # ...
}
```

#### 4.3 Preflight Flow

```
preflight("attack_type")
    │
    ├─► Check all requirements
    │
    ├─► All met? → return 0 (success)
    │
    └─► Missing requirements:
        ├─► Show what's missing with descriptions
        ├─► Show install commands where applicable
        ├─► Offer auto-fix if possible
        └─► return 1 (failure)
```

---

### Phase 5: Target Acquisition System

#### 5.1 Scan Before Attack

Attacks needing a target should auto-scan:

```bash
_do_wps_pixie() {
    preflight "wps_pixie" || return 1
    
    # Auto-scan if no target
    if ! has_target || [[ ${#SCAN_WPS[@]} -eq 0 ]]; then
        scan_wps "$_MONITOR_IFACE" 20
        select_wps_target || return 1
    fi
    
    # Now TARGET_BSSID, TARGET_CHANNEL, TARGET_ESSID are set
    # Proceed with attack...
}
```

#### 5.2 Scan Result Display

```
    ━━━ SELECT TARGET ━━━
    
    NUM BSSID              CH ESSID                    ENC      PWR
    ─────────────────────────────────────────────────────────────────
      1) AA:BB:CC:DD:EE:FF  6  HomeNetwork              WPA2     -45 [3 clients]
      2) 11:22:33:44:55:66 11  CoffeeShop               WPA2     -52 [5 clients]
      3) 99:88:77:66:55:44  1  OldRouter                WEP      -58
    
    [S] Rescan  [M] Manual entry  [0] Cancel
    
    ▶ Select target: 
```

#### 5.3 Client Selection for Deauth

```bash
_do_deauth() {
    # ...get target...
    
    # Let user pick specific client or broadcast
    select_client  # Sets TARGET_CLIENT or leaves empty for broadcast
    
    if [[ -n "$TARGET_CLIENT" ]]; then
        aireplay-ng -0 10 -a "$TARGET_BSSID" -c "$TARGET_CLIENT" "$iface"
    else
        aireplay-ng -0 10 -a "$TARGET_BSSID" "$iface"
    fi
}
```

---

### Phase 6: Apply Pattern to Other Menus

Repeat the upgrade pattern for:

1. **Recon Menu** (`lib/menus/recon_menu.sh`)
   - Add RECON_HELP array
   - Add preflight for nmap, masscan, etc.
   - No targeting needed (uses IP/host input)

2. **Scanning Menu** (`lib/menus/scan_menu.sh`)
   - Add SCAN_HELP array
   - Preflight for port scanners
   - Target = IP address input

3. **Credentials Menu** (`lib/menus/creds_menu.sh`)
   - Add CREDS_HELP array
   - Preflight for hashcat, john, hydra
   - Targeting for selecting hash/capture files

4. **OSINT Menu** (`lib/menus/osint_menu.sh`)
   - Add OSINT_HELP array
   - Minimal preflight (mostly web tools)
   - No network targeting

5. **Traffic Menu** (`lib/menus/traffic_menu.sh`)
   - Add TRAFFIC_HELP array
   - Preflight for tcpdump, wireshark, bettercap
   - Interface selection

6. **Exploit Menu** (`lib/menus/exploit_menu.sh`)
   - Add EXPLOIT_HELP array
   - Preflight for metasploit, sqlmap
   - Target IP/URL input

7. **Stress Menu** (`lib/menus/stress_menu.sh`)
   - Add STRESS_HELP array
   - Preflight for hping3, etc.
   - Target IP input with warnings

---

## Code Standards

### Function Naming

```
show_XXXX_menu_smart()   - Main menu function
_show_XXXX_options()     - Display menu items
_handle_XXXX_choice()    - Process user selection
_do_XXXX_attack()        - Execute specific attack
```

### Variable Naming

```
_CURRENT_IFACE      - Selected wireless interface
_MONITOR_IFACE      - Interface in monitor mode
TARGET_BSSID        - Target AP MAC
TARGET_CHANNEL      - Target channel
TARGET_ESSID        - Target network name
TARGET_CLIENT       - Target client MAC (for deauth)
SCAN_RESULTS        - Array of scan results
SCAN_WPS            - Array of WPS scan results
SCAN_CLIENTS        - Array of detected clients
```

### Color Codes

```bash
C_RESET   - Reset
C_RED     - Errors, warnings, dangerous operations
C_GREEN   - Success, satisfied requirements
C_YELLOW  - Warnings, cautions
C_CYAN    - Info, headers, prompts
C_PURPLE  - Branding, main headers
C_WHITE   - Emphasis
C_SHADOW  - De-emphasized text, hints
```

---

## Testing Checklist

For each upgraded menu:

- [ ] Menu displays correctly with all options
- [ ] `?` or `H` opens help screen
- [ ] `?N` shows help for specific option N
- [ ] Status bar shows current state
- [ ] Preflight catches missing requirements
- [ ] Preflight offers auto-fix where applicable
- [ ] Auto-scan triggers when target needed
- [ ] Target selection works from scan results
- [ ] Manual entry fallback works
- [ ] Attacks execute with correct parameters
- [ ] Error messages are clear and actionable
- [ ] `0` returns to previous menu
- [ ] No crashes on invalid input

---

## Example: Complete WPS Pixie-Dust Flow

```
User selects: 10) Pixie-Dust

1. preflight("wps_pixie") runs:
   - Check root: ✓
   - Check monitor_mode: ✗ MISSING
   
2. Show missing requirements:
   ━━━ MISSING REQUIREMENTS ━━━
   ✗ Monitor mode enabled
     → Enable monitor mode from menu option 2
   
   Can auto-fix 1 requirement(s)
   Auto-fix now? [y/N]: y

3. Auto-fix runs:
   ⟳ Enabling monitor mode...
   ✓ Monitor mode: wlan0mon

4. preflight re-runs:
   - Check root: ✓
   - Check monitor_mode: ✓
   - Check reaver|bully: ✓
   - Check pixiewps: ✓
   ✓ All requirements satisfied

5. No target - auto-scan:
   ⟳ Scanning for WPS networks (20s)...
   [████████████████████] 100%
   Found 3 WPS-enabled networks

6. Show WPS targets:
   ━━━ WPS TARGETS ━━━
   NUM BSSID              CH ESSID              LOCKED VER
   ──────────────────────────────────────────────────────
     1) AA:BB:CC:DD:EE:FF  6  HomeNetwork        No     2.0
     2) 11:22:33:44:55:66 11  CoffeeShop         YES    1.0
   
   ▶ Select target: 1

7. Confirm and execute:
   ━━━ PIXIE-DUST ATTACK ━━━
   Target: HomeNetwork (AA:BB:CC:DD:EE:FF)
   Channel: 6
   
   Start attack? [y/N]: y
   
   ⟳ Running Pixie-Dust...
   [reaver output...]
```

---

## Files Provided in This Package

```
voidwave-upgrade/
├── lib/
│   └── intelligence/
│       ├── help.sh              # Help system with WIRELESS_HELP
│       ├── preflight.sh         # Requirement checking system
│       ├── targeting.sh         # Network scanning & selection
│       └── wireless_menu_smart.sh  # Complete upgraded wireless menu
├── docs/
│   └── IMPLEMENTATION_GUIDE.md  # This file
└── prompts/
    └── CLAUDE_CODE_PROMPT.md    # Master prompt for Claude Code CLI
```

---

## Integration Steps Summary

1. Copy `lib/intelligence/` to `VOIDWAVE/lib/`
2. Update `lib/wireless_loader.sh` to source intelligence modules
3. Update `lib/menu.sh` to call `show_wireless_menu_smart`
4. Test wireless menu thoroughly
5. Repeat pattern for remaining menus
6. Add menu-specific help arrays to `help.sh`
7. Add attack requirements to `preflight.sh`

---

## Questions for Implementation

Before starting, confirm:

1. Should help be accessible via `?` only, or also `H` and `help`?
2. Should auto-fix be opt-in (ask first) or automatic?
3. Should scans be saved to files for later review?
4. Should there be a "recent targets" memory?
5. What's the default scan duration preference?

---

**END OF IMPLEMENTATION GUIDE**
