# VOIDWAVE Smart Menu Upgrade - Claude Code CLI Prompt

## Project Context

You are upgrading VOIDWAVE, an offensive security framework written in Bash. The current menu system is functional but lacks intelligence - users must manually enter BSSIDs, channels, and other parameters. The upgrade adds:

1. **Help System** - `?` or `H` at menu bottom shows detailed descriptions
2. **Pre-flight Checks** - Validate requirements before attacks execute
3. **Auto-scanning** - Scan networks before attacks that need targets
4. **Smart Selection** - Present scan results as selectable lists
5. **Auto-fix** - Attempt to resolve missing requirements automatically

## Repository Structure

```
VOIDWAVE/
├── lib/
│   ├── core.sh           # Logging, colors, utilities
│   ├── ui.sh             # Banners, prompts, progress
│   ├── menu.sh           # Main menu (1880 lines)
│   ├── wireless_loader.sh # Module loader
│   ├── menus/
│   │   ├── wireless_menu.sh
│   │   ├── recon_menu.sh
│   │   ├── scan_menu.sh
│   │   ├── creds_menu.sh
│   │   ├── osint_menu.sh
│   │   ├── traffic_menu.sh
│   │   ├── exploit_menu.sh
│   │   ├── stress_menu.sh
│   │   └── settings_menu.sh
│   ├── attacks/          # Attack implementations
│   └── wireless/         # Wireless utilities
├── modules/              # Legacy module files
└── VERSION               # Currently 10.0.0
```

## Upgrade Package Contents

The upgrade package (`voidwave-upgrade.zip`) contains:

```
lib/intelligence/
├── help.sh               # Help system with descriptions
├── preflight.sh          # Requirement checking
├── targeting.sh          # Network scanning & selection
└── wireless_menu_smart.sh # Reference implementation
```

## Your Tasks

### Task 1: Install Intelligence Layer

1. Copy `lib/intelligence/` directory to `VOIDWAVE/lib/`
2. Ensure files are executable: `chmod +x lib/intelligence/*.sh`

### Task 2: Update Wireless Loader

Edit `lib/wireless_loader.sh`:

```bash
# Find _wireless_core_modules array and add:
_wireless_core_modules=(
    "intelligence/help.sh"      # ADD
    "intelligence/preflight.sh" # ADD  
    "intelligence/targeting.sh" # ADD
    "wireless/config.sh"
    "wireless/adapter.sh"
    # ... rest of existing modules
)
```

### Task 3: Replace Wireless Menu Function

In `lib/menu.sh`, find `show_wireless_menu_new()` (around line 500) and either:

**Option A:** Replace the entire function with contents from `wireless_menu_smart.sh`

**Option B:** Update the call to use the new function:
```bash
# In main menu case statement:
4) show_wireless_menu_smart || true ;;
```

### Task 4: Verify Integration

Test that:
- `?` opens help screen
- Options 1-4 (interface management) work
- Options 10-13 (WPS) run preflight and auto-scan
- Options 20-22 (WPA) run preflight and auto-scan
- Status bar shows current interface/monitor/target

### Task 5: Extend to Other Menus

Apply the same pattern to upgrade remaining menus. For each menu:

1. Create help entries in `lib/intelligence/help.sh`:
```bash
declare -gA MENUNAME_HELP=(
    [1]="OPTION ONE TITLE

    Description of what this option does.
    
    REQUIREMENTS: List what's needed
    USE CASES: When to use this"
    
    [2]="OPTION TWO TITLE
    ..."
)
```

2. Add requirement definitions in `lib/intelligence/preflight.sh`:
```bash
ATTACK_REQUIREMENTS+=(
    [attack_name]="req1 req2 tool1|tool2"
)
```

3. Update menu function to:
   - Call `handle_help_input` for `?` handling
   - Call `preflight` before attacks
   - Use `acquire_target` for target-dependent operations

## Code Patterns

### Menu Function Pattern
```bash
show_XXX_menu_smart() {
    while true; do
        clear; _show_banner; _show_status; _show_options
        
        local choice=$(_prompt)
        handle_help_input "$choice" "menuname" && continue
        
        case "$choice" in
            1) _do_option_one ;;
            0) return 0 ;;
        esac
    done
}
```

### Attack Function Pattern
```bash
_do_attack_xxx() {
    preflight "attack_name" || return 1
    
    if ! has_target; then
        acquire_target "$_MONITOR_IFACE" "wps"
    fi
    
    # Execute attack with $TARGET_BSSID, $TARGET_CHANNEL, etc.
}
```

### Help Entry Pattern
```bash
[NUM]="TITLE IN CAPS

    First paragraph explains what it does.
    
    HOW IT WORKS:
    • Step one
    • Step two
    
    REQUIREMENTS: What's needed
    
    TIP: Helpful advice"
```

## Testing Commands

After integration, test with:

```bash
# Run VOIDWAVE
sudo ./voidwave

# In wireless menu:
# - Press ? to see help
# - Press ?10 to see Pixie-Dust help
# - Select option 10 without monitor mode to test preflight
# - Test auto-scanning flow
```

## Important Notes

1. **Don't break existing functionality** - The smart menu is an upgrade, not rewrite
2. **Preserve color variables** - Use existing `$C_RED`, `$C_GREEN`, etc.
3. **Match coding style** - Follow existing patterns in the codebase
4. **Test incrementally** - Verify each menu works before moving to next
5. **Keep menus clean** - Descriptions go in help system, not inline

## Success Criteria

The upgrade is complete when:

- [ ] All menus have `?` help option working
- [ ] Help shows detailed descriptions for each option
- [ ] Pre-flight checks run before attacks
- [ ] Missing requirements are clearly shown with fix instructions
- [ ] Auto-fix works for interface/monitor mode
- [ ] Network scans run automatically when targets needed
- [ ] Scan results display as selectable numbered lists
- [ ] Selected targets persist across menu operations
- [ ] Status bar shows current state
- [ ] No regressions in existing functionality

## Questions to Ask If Stuck

1. Where is function X defined? → `grep -rn "function_name" lib/`
2. What sources what? → `grep -rn "source.*filename" lib/`
3. What's the current flow? → Read `lib/menu.sh` from line 147
4. Why isn't X loading? → Check `lib/wireless_loader.sh` module arrays

---

**Execute these tasks in order. Test after each major change. Report any errors with full context.**
