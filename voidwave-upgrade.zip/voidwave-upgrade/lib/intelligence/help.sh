#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
# VOIDWAVE Help System
# ═══════════════════════════════════════════════════════════════════════════════
# Provides detailed descriptions for all menu options
# Access via: ? or H from any menu, or ?<num> for specific option
# ═══════════════════════════════════════════════════════════════════════════════

[[ -n "${_VOIDWAVE_HELP_LOADED:-}" ]] && return 0
declare -r _VOIDWAVE_HELP_LOADED=1

# ═══════════════════════════════════════════════════════════════════════════════
# WIRELESS MENU DESCRIPTIONS
# ═══════════════════════════════════════════════════════════════════════════════

declare -gA WIRELESS_HELP=(
    # Interface Section
    [1]="SELECT INTERFACE
    
    Choose which wireless adapter to use for attacks.
    
    Shows all available WiFi interfaces with:
    • Current mode (managed/monitor)
    • Driver information
    • Chipset details
    
    TIP: Use adapters with Atheros AR9271 or Ralink RT3070 
    chipsets for best injection support."

    [2]="ENABLE MONITOR MODE
    
    Switch interface to monitor mode for packet capture/injection.
    
    This will:
    • Kill interfering processes (NetworkManager, wpa_supplicant)
    • Put adapter in monitor mode
    • Verify injection capability
    
    REQUIRED for: All wireless attacks, scanning
    
    WARNING: Normal WiFi connectivity will be disabled until 
    you run 'Monitor Mode OFF'"

    [3]="DISABLE MONITOR MODE
    
    Restore interface to managed mode.
    
    This will:
    • Stop monitor mode
    • Restart NetworkManager
    • Restore normal WiFi connectivity
    
    Use when finished with wireless attacks."

    [4]="MAC ADDRESS SPOOFING
    
    Change your adapter's MAC address.
    
    Options:
    • Random MAC - fully randomized
    • Specific MAC - clone another device
    • Vendor spoof - match Intel/Broadcom/etc
    • Restore original
    
    USE CASES:
    • Avoid MAC filtering
    • Impersonate authorized device
    • Evade detection/logging"

    # Scanning Section
    [5]="SCAN NETWORKS
    
    Discover all nearby wireless networks.
    
    Displays:
    • ESSID (network name)
    • BSSID (AP MAC address)
    • Channel
    • Encryption (Open/WEP/WPA/WPA2/WPA3)
    • Signal strength (PWR)
    • Connected clients
    
    Press Ctrl+C to stop scanning.
    
    TIP: Let it run 30-60 seconds to discover all networks 
    and see client activity."

    [6]="DETAILED TARGET SCAN
    
    Focus scan on a specific network.
    
    Shows:
    • All connected clients with MAC addresses
    • Client signal strength
    • Data/packet counts
    • Probe requests
    
    USEFUL FOR: Identifying high-value clients for deauth, 
    checking network activity before attacks."

    # WPS Section
    [10]="PIXIE-DUST ATTACK
    
    Offline WPS PIN recovery exploiting weak RNG.
    
    HOW IT WORKS:
    1. Captures M1/M2 WPS exchange from target
    2. Extracts E-S1/E-S2 nonces
    3. Cracks PIN offline using pixiewps
    
    SUCCESS RATE: ~30% of WPS-enabled routers
    TIME: Seconds to minutes (offline crack)
    
    TOOLS: reaver + pixiewps (or bully + pixiewps)
    
    TRY THIS FIRST - fastest WPS attack when vulnerable."

    [11]="WPS PIN BRUTEFORCE
    
    Online attack trying all possible WPS PINs.
    
    HOW IT WORKS:
    • Tests PINs against live AP
    • 11,000 possible combinations
    • Checksum reduces to ~11,000 attempts
    
    TIME: 4-10 hours (depends on AP rate limiting)
    
    WATCH FOR:
    • AP lockouts (60-second to permanent)
    • Rate limiting (slows attack)
    
    Use when Pixie-Dust fails."

    [12]="KNOWN PINS DATABASE
    
    Try manufacturer default PINs.
    
    Many routers ship with predictable PINs:
    • Belkin: often 12345670
    • D-Link: MAC-based patterns
    • TP-Link: serial-based
    • Netgear: label-based
    
    SPEED: Very fast - only tries known PINs
    
    Run this before bruteforce to save hours."

    [13]="ALGORITHM PIN ATTACK
    
    Calculate PIN from router MAC/serial.
    
    ALGORITHMS:
    • ComputePIN - BSSID-based calculation
    • EasyBox - Arcadyan/EasyBox routers
    • Arcadyan - specific vendor algorithm
    
    Works when manufacturer generates PINs 
    algorithmically rather than randomly.
    
    SPEED: Instant calculation, quick test"

    # WPA Section
    [20]="PMKID CAPTURE
    
    Capture PMKID hash WITHOUT client deauth.
    
    HOW IT WORKS:
    1. Send association request to AP
    2. AP responds with PMKID in first EAPOL frame
    3. Crack PMKID offline with hashcat
    
    ADVANTAGES:
    • No clients needed
    • No deauth required (stealthier)
    • Works on ~70% of WPA2 networks
    
    TOOLS: hcxdumptool + hcxpcapngtool
    
    FASTEST method to get crackable WPA hash."

    [21]="HANDSHAKE CAPTURE
    
    Capture 4-way WPA handshake.
    
    HOW IT WORKS:
    1. Monitor target channel
    2. Deauth connected client
    3. Capture handshake when client reconnects
    
    REQUIRES: At least one client connected
    
    OUTPUT: .cap file for aircrack-ng/hashcat
    
    Classic WPA attack - works on all WPA/WPA2."

    [22]="SMART HANDSHAKE CAPTURE
    
    Intelligent automated handshake capture.
    
    FEATURES:
    • Auto-detects connected clients
    • Targets strongest signal client
    • Validates capture in real-time
    • Stops when valid handshake obtained
    • Retries failed deauths
    
    ADVANTAGE: Set and forget - handles edge cases."

    # Evil Twin Section
    [30]="EVIL TWIN - FULL ATTACK
    
    Complete rogue AP with captive portal.
    
    ATTACK FLOW:
    1. Capture handshake from target (for validation)
    2. Create identical fake AP
    3. Deauth clients from real AP
    4. Serve phishing portal
    5. Validate submitted passwords
    6. Save correct password
    
    REQUIRES: 2 interfaces OR VIF support
    
    CUSTOMIZATION: Multiple portal templates, 
    language selection, vendor logos."

    [31]="EVIL TWIN - OPEN HONEYPOT
    
    Simple open network trap.
    
    Creates open WiFi to:
    • Capture probe requests
    • See what networks devices seek
    • Catch auto-connecting devices
    
    NO portal - just monitoring.
    
    GOOD FOR: Reconnaissance, passive intel."

    [32]="EVIL TWIN - WPA HONEYPOT
    
    Fake secured network.
    
    Creates WPA-protected AP to:
    • Capture connection attempts
    • Log PSK guesses
    • Test for downgrade attacks
    
    Set your own password to catch 
    devices trying known passwords."

    # DoS Section
    [40]="DEAUTHENTICATION ATTACK
    
    Disconnect clients from access point.
    
    OPTIONS:
    • Broadcast - kick all clients
    • Targeted - specific client MAC
    
    USES:
    • Force handshake capture
    • Denial of service
    • Force client to Evil Twin
    
    PACKET COUNT: Higher = more aggressive
    
    WARNING: Easily detected by WIDS"

    [41]="AMOK MODE
    
    Mass deauthentication attack.
    
    Hits ALL detected networks simultaneously.
    
    TOOL: mdk4
    
    AGGRESSIVE - use in controlled environments.
    
    WARNING: Major disruption, highly visible."

    [42]="BEACON FLOOD
    
    Create thousands of fake APs.
    
    EFFECTS:
    • Confuses WiFi scanners
    • Overwhelms client lists
    • Can crash some devices
    
    OPTIONS:
    • Random SSIDs
    • Wordlist SSIDs
    • Clone nearby networks
    
    TOOL: mdk4"

    [43]="PURSUIT MODE
    
    Follow channel-hopping targets.
    
    Some APs change channels to evade attacks.
    Pursuit mode:
    • Detects channel changes
    • Follows target automatically
    • Maintains continuous DoS
    
    TOOL: mdk4
    
    Defeats basic evasion attempts."

    # Legacy Section
    [50]="WEP ATTACK SUITE
    
    Full WEP cracking toolkit.
    
    METHODS:
    • ARP Replay - generate IVs fast
    • Fragmentation - works without clients
    • Chop-Chop - another clientless method
    • PTW - crack with fewer IVs
    
    WEP IS BROKEN - success virtually guaranteed.
    
    Need ~20,000-40,000 IVs to crack.
    
    TIME: Minutes to hours depending on traffic."

    [51]="ENTERPRISE ATTACK
    
    WPA-Enterprise / 802.1X attacks.
    
    ATTACK: Fake RADIUS server
    
    HOW IT WORKS:
    1. Create rogue AP with WPA-Enterprise
    2. Client connects, sends credentials
    3. Capture MSCHAP hash
    4. Crack offline
    
    TOOLS: hostapd-wpe, freeradius
    
    TARGETS: Corporate networks using PEAP/MSCHAP"

    # Advanced Section
    [60]="HIDDEN SSID REVEAL
    
    Discover cloaked network names.
    
    METHODS:
    • Deauth attack - force probe responses
    • Dictionary attack - common SSIDs
    • Passive wait - client probes
    
    Hidden SSIDs provide NO real security.
    
    Network always revealed when clients connect."

    [61]="WPA3 DOWNGRADE TEST
    
    Check for WPA3 vulnerabilities.
    
    TESTS:
    • Accepts WPA2 when advertising WPA3?
    • Transition mode weaknesses
    • Dragonfly handshake issues
    
    WPA3 often deployed in transition mode 
    allowing WPA2 fallback attacks."

    [62]="WIFITE AUTOMATED AUDIT
    
    Launch wifite for hands-off testing.
    
    WIFITE HANDLES:
    • Interface management
    • Network scanning
    • Attack selection
    • Capture/cracking
    
    GOOD FOR: Quick assessments, lazy audits
    
    Less control but fully automated."
)

# ═══════════════════════════════════════════════════════════════════════════════
# HELP DISPLAY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

# Show help for a specific option
# Args: $1 = menu name (wireless, recon, etc), $2 = option number
show_option_help() {
    local menu="$1"
    local option="$2"
    local -n help_array="${menu^^}_HELP"
    
    local help_text="${help_array[$option]:-}"
    
    clear_screen 2>/dev/null || clear
    echo ""
    echo -e "    ${C_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${C_RESET}"
    echo -e "    ${C_WHITE}HELP: Option $option${C_RESET}"
    echo -e "    ${C_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${C_RESET}"
    echo ""
    
    if [[ -n "$help_text" ]]; then
        echo "$help_text" | sed 's/^/    /'
    else
        echo -e "    ${C_SHADOW}No help available for option $option${C_RESET}"
    fi
    
    echo ""
    echo -e "    ${C_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${C_RESET}"
    echo ""
    echo -e "    ${C_SHADOW}Press Enter to return...${C_RESET}"
    read -r
}

# Show full help screen for a menu
# Args: $1 = menu name
show_menu_help() {
    local menu="$1"
    local -n help_array="${menu^^}_HELP"
    
    clear_screen 2>/dev/null || clear
    echo ""
    echo -e "    ${C_PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${C_RESET}"
    echo -e "    ${C_WHITE}${menu^^} MENU - HELP & DESCRIPTIONS${C_RESET}"
    echo -e "    ${C_PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${C_RESET}"
    echo ""
    echo -e "    ${C_SHADOW}Enter option number to see detailed help, or 0 to return${C_RESET}"
    echo ""
    
    # List all available options with first line of description
    for key in $(echo "${!help_array[@]}" | tr ' ' '\n' | sort -n); do
        local first_line
        first_line=$(echo "${help_array[$key]}" | head -1 | xargs)
        printf "    ${C_CYAN}%3s${C_RESET}) %s\n" "$key" "$first_line"
    done
    
    echo ""
    echo -e "    ${C_SHADOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${C_RESET}"
    echo ""
    
    while true; do
        echo -en "    ${C_PURPLE}?${C_RESET} Help for option [0=back]: "
        read -r choice
        
        [[ "$choice" == "0" || "$choice" == "q" || -z "$choice" ]] && return 0
        
        if [[ -n "${help_array[$choice]:-}" ]]; then
            show_option_help "$menu" "$choice"
            show_menu_help "$menu"  # Redisplay help menu
            return 0
        else
            echo -e "    ${C_RED}No help for option $choice${C_RESET}"
        fi
    done
}

# Handle help input from menu
# Args: $1 = input (? or ?<num> or h or h<num>), $2 = menu name
# Returns: 0 if help was shown, 1 if not a help request
handle_help_input() {
    local input="$1"
    local menu="$2"
    
    case "$input" in
        "?"|"h"|"H"|"help"|"HELP")
            show_menu_help "$menu"
            return 0
            ;;
        "?"[0-9]*|"h"[0-9]*|"H"[0-9]*)
            local num="${input:1}"
            show_option_help "$menu" "$num"
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# ═══════════════════════════════════════════════════════════════════════════════
# EXPORTS
# ═══════════════════════════════════════════════════════════════════════════════

export -f show_option_help show_menu_help handle_help_input
